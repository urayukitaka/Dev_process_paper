'''
KR_sim_model.py

KR毎にPassRatioの分布をシミュレーションする
'''

# Libraries
import os
import sys
sys.path.append("../src")

import numpy as np
import pandas as pd
import scipy
import matplotlib.pyplot as plt

# 分散処理
from tqdm import tqdm
from joblib import Parallel, delayed

import utils as u
u.graph_setting() # graph format

# Simulation class
class SimPassRatio:

    def __init__(self, x_max, y_max):

        # dimension
        self.x_max = x_max
        self.y_max = y_max

        # initialize initial matrix
        self.init_mat()

    # make initial matrix
    def init_mat(self):
        # make initial
        self.mat = pd.DataFrame({"X":[], "Y":[]})

        # simulated square map
        x = np.arange(1, self.x_max+1)
        y = np.arange(1, self.y_max+1)
        xc = np.max(x)/2
        yc = np.max(y)/2
        # make matrix
        for x_ in x:
            for y_ in y:
                r = res_r(x_, y_, xc, yc)
                if r<xc+1 :
                    self.mat = pd.concat([self.mat, pd.DataFrame({"X":x_, "Y":y_}, index=[0])])
        # reset index
        self.mat.reset_index(drop=True, inplace=True)

    # select initial fails
    def random_fail(self, fail_count:int):

        # fail = 0, pass = 1
        # random index
        rand_idx = np.random.permutation(len(self.mat))

        # select fail index
        rand_idx = rand_idx[:fail_count]

        # make pass s
        pass_flgs = np.ones(len(self.mat))

        # fail select
        for i in rand_idx:
            pass_flgs[i] = 0

        # add matrix
        self.mat["Pass"] = pass_flgs
        self.mat["Pass"] = self.mat["Pass"].astype("int")

    # random dust
    def random_dust(self, dust_count:int):

        # r and s
        r = self.x_max/2
        # center
        xc = self.x_max/2
        yc = self.y_max/2

        # x_list and y_list
        x_list = []
        y_list = []

        while len(x_list)<dust_count:
            # sampling
            # random x
            xs = scipy.stats.uniform.rvs(loc=0, scale=self.x_max ,size=1)[0]
            # random y
            ys = scipy.stats.uniform.rvs(loc=0, scale=self.y_max, size=1)[0]
            # calc r
            samp_r = res_r(xs, ys, xc, yc)
            # check r range
            if samp_r <= r:
                x_list.append(xs)
                y_list.append(ys)

        self.rdust = pd.DataFrame({"x":x_list, "y":y_list})

        # count dust each chips
        self.count_dust()


    # count dust in each chips
    def count_dust(self):

        dust_cnts = []

        # count each chip
        for idx, items in self.mat.iterrows():
            # tip
            xc = items[0]
            yc = items[1]

            # check each x, y dust
            count = len(self.rdust[(self.rdust["x"]>=xc-0.5)&(self.rdust["x"]<xc+0.5)&(self.rdust["y"]>=yc-0.5)&(self.rdust["y"]<yc+0.5)])
            dust_cnts.append(count)

        self.mat["Dust_count"] = dust_cnts

    # kill simulation
    def kill_sim(self, kill_ratio):
        self.mat["Kill"] = [res_fail_or_pass(kill_ratio, cnt) if cnt!=0 else 0 for cnt in self.mat["Dust_count"]]

    def calc_PassRatio(self):

        # pass chips
        pass_df = self.mat[self.mat["Pass"]==1]

        # pass
        pass_size = len(pass_df)
        # killed
        kill_size = len(pass_df[pass_df["Kill"]==1])

        # Pass rate
        pass_rate = (pass_size - kill_size)/pass_size

        # failure rate
        failure_rate =  kill_size/pass_size

        # failure rate by ideal y
        failure_rate_iy =  kill_size/len(self.mat)

        # Dust on chip
        dust_on_chip = len(self.mat[self.mat["Dust_count"]!=0]) / len(self.mat)

        return pass_rate, failure_rate, failure_rate_iy, dust_on_chip

    # calc each pass rate plot
    def job(self, fail_count):

        # range
        dust_count = np.arange(0, 2000, 50)
        kr_list = [1.0, 0.8, 0.6, 0.4, 0.2, 0.01]

        # list
        fail_count_res = []
        dust_count_res = []
        killer_rate_res = []
        pass_rate_res = []
        failure_rate_res = []
        failure_rate_iy_res = []
        dust_on_chip_res = []

        # make random dust and add map

        # random simulation
        for i in tqdm(range(4), "| Trial |"):
            # random fail
            self.random_fail(fail_count)
            for dc in dust_count:
                self.random_dust(dc)
                for kr in kr_list:
                    # kill simulation
                    self.kill_sim(kr)
                    # failure rate and pass rate
                    pr, fr, fr_iy, doc = self.calc_PassRatio()
                    # result
                    fail_count_res.append(fail_count)
                    dust_count_res.append(dc)
                    killer_rate_res.append(kr)
                    pass_rate_res.append(pr)
                    failure_rate_res.append(fr)
                    failure_rate_iy_res.append(fr_iy)
                    dust_on_chip_res.append(doc)

        # merge job result to sim result
        job_result = pd.DataFrame({"fail_count":fail_count_res,
                                "dust_count":dust_count_res,
                                "killer_rate":killer_rate_res,
                                "pass_rate":pass_rate_res,
                                "failure_rate":failure_rate_res,
                                "failure_rate_iy":failure_rate_iy_res,
                                "dust_on_chip":dust_on_chip_res})
        return job_result

    # get each map
    def sample_each_result(self, fail_count, dust_count, killer_rate, savedir=None):

        # make initial map
        self.init_mat()
        # random fail
        self.random_fail(fail_count)
        # make random dust
        self.random_dust(dust_count)
        # kill simulation
        self.kill_sim(killer_rate)
        # calc pass rate
        pr, fr, fr_iy, dc = self.calc_PassRatio()

        # make map
        plt.figure(figsize=(11,10))
        # dust
        plt.scatter(self.rdust["x"], self.rdust["y"], label="Dust", marker="x")
        # chip center passed
        plt.scatter(self.mat[self.mat["Pass"]==1]["X"], self.mat[self.mat["Pass"]==1]["Y"], c="black", s=5, label="Chips")
        # Fail simulated chip
        plt.scatter(self.mat[(self.mat["Kill"]==1)&(self.mat["Pass"]==1)].X, self.mat[(self.mat["Kill"]==1)&(self.mat["Pass"]==1)].Y, c="red", s=120, label="Fail", alpha=0.5)
        # plot property
        plt.xlim([-0.5, self.x_max+1.5])
        plt.ylim([-0.5, self.y_max+1.5])
        plt.grid(True, which='major', linewidth=0.1)
        plt.xticks(np.arange(self.x_max+2)-0.5, rotation=90)
        plt.yticks(np.arange(self.y_max+2)-0.5)
        plt.title("SimulationResult_Pass{}/Iy{}\ninit_KR{}_FailbyDust{}/DustOnPass{}(Dust{})\nPR{}".format(
                                                int(len(self.mat) - fail_count), # Passed chips before
                                                len(self.mat), # Ideal y
                                                killer_rate, # killer rate
                                                len(self.mat[(self.mat["Kill"]==1)&(self.mat["Pass"]==1)]), # passed
                                                len(self.mat[(self.mat["Dust_count"]!=0)&(self.mat["Pass"]==1)]),
                                                dust_count, # dust_count
                                                round(pr,2) # pass rate)
        ))
        plt.legend()
        # save if savedir is not None
        if savedir!=None:
            plt.savefig(
                os.path.join(savedir,
                             "SimulationResult_Pass{}_Iy{}_init_KR{}_FailbyDust{}_DustOnPass{}(Dust{})_PR{}.png".format(
                                                int(len(self.mat) - fail_count), # Passed chips before
                                                len(self.mat), # Ideal y
                                                killer_rate, # killer rate
                                                len(self.mat[(self.mat["Kill"]==1)&(self.mat["Pass"]==1)]), # passed
                                                len(self.mat[(self.mat["Dust_count"]!=0)&(self.mat["Pass"]==1)]),
                                                dust_count, # dust_count
                                                round(pr,2) # pass rate)
            )))

        if savedir==None:
            plt.show()
        else:
            plt.close()

def res_r(x, y, xc, yc):
    return np.sqrt((x-xc)**2 + (y-yc)**2)

# Judge fail or pass by KR
def res_fail_or_pass(KR:float, count:int):
    # initial
    res = 0
    # judge by KR
    for cycle in range(count):
        if np.random.random()<KR:
            res = 1
        else:
            if res==1:
                break
            else:
                res = 0
    return res

def exe(fail_count_list:list, x_max, y_max, savedir):

    # simulation result
    sim_result = pd.DataFrame({})

    # instance
    sim = SimPassRatio(x_max=x_max, y_max=y_max)

    # subprocess
    Results = Parallel(n_jobs=-1)([delayed(sim.job)(fc) for fc in fail_count_list])

    # cocating
    for i in range(len(Results)):
        sim_result = pd.concat([sim_result, Results[i]])

    return sim_result


if __name__ == "__main__":

    # -----------------------------------------------
    # Initial parameter
    # wafer chip dimension
    x_max = 32
    y_max = 32

    # fail count pattern list
    fail_count_list = [0, 50, 100, 150, 200, 250, 300, 350, 400, 450, 500]

    # save result
    savedir = r"C:\Users\yktkk\Desktop\DS_practice\Data_science\Work\KR_prediction_model\Test"
    # -----------------------------------------------

    # -----------------------------------------------
    # exe
    # map check
    print("Confiming sample map examples")
    # sample
    fc_sample = [0, 100, 200, 300, 400]
    dc_sample = [100, 200, 400, 800, 1600]
    kr_sample = [1.0, 0.8, 0.6]
    sim = SimPassRatio(x_max=x_max, y_max=y_max)

    for fc in fc_sample:
        for dc in dc_sample:
            for kr in kr_sample:
                print(f"Simulation : fc {fc}, dc {dc}, kr {kr}")
                sim.sample_each_result(fc, dc, kr, savedir=savedir)

    # sampling sim
    result = exe(fail_count_list=fail_count_list, x_max=x_max, y_max=y_max, savedir=savedir)
    # save result
    result.to_csv(os.path.join(savedir, "result.csv"), index=False, encoding="CP932")

    # plot
    unique_kr = result["killer_rate"].unique()

    #plt.figure(figsize=(11,10))
    fig, ax = plt.subplots(1, 3, figsize=(32, 10))
    for kr in unique_kr:

        # slice each killer rate
        result_ = result[result["killer_rate"]==kr]
        dc = result_["dust_count"].values
        pr = result_["pass_rate"].values
        fr = result_["failure_rate"].values
        fr_iy = result_["failure_rate_iy"].values
        # plot
        ax[0].scatter(dc, pr, label = f"Killer Rate : {kr}", s=5)
        ax[1].scatter(dc, fr, label = f"Killer Rate : {kr}", s=5)
        ax[2].scatter(dc, fr_iy, label = f"Killer Rate : {kr}", s=5)

    for i in [0,1]:
        ax[i].legend()
        ax[i].set_xlabel("Dust count")
        if i==0:
            ax[i].set_ylabel("Pass rate (/pass chip)")
        elif i==1:
            ax[i].set_ylabel("Failure rate (/pass chip)")
        elif i==2:
            ax[i].set_ylabel("Failure rate (/Ideal Yield)")
        ax[i].set_ylim([-0.02,1.02])
        ax[i].set_title("Simulation_result")

    plt.savefig(os.path.join(savedir, "SimulationResult.png"))
    # -----------------------------------------------
